let ListErrors = {
  bindings: {
    errors: '='
  },
  templateUrl: 'components/list-errors.html'
}

export default ListErrors;
