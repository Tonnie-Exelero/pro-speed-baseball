let ArticlePreview = {
  bindings: {
    article: '='
  },
  templateUrl: 'components/article-helpers/article-preview.html'
};

export default ArticlePreview;
